plugins {
    id("com.android.application")
}

android {
    namespace = "com.andrei.nfcpeople"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.andrei.nfcpeople"
        minSdk = 26
        targetSdk = 36
        versionCode = 23
        versionName = "2.0.2"
    }

    signingConfigs {
        create("stableTest") {
            storeFile = file("nfc-people-test.jks")
            storePassword = "nfcpeople-test-2026"
            keyAlias = "nfcpeople"
            keyPassword = "nfcpeople-test-2026"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("stableTest")
        }
        release {
            signingConfig = signingConfigs.getByName("stableTest")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}


dependencies {
    testImplementation("junit:junit:4.13.2")
}
