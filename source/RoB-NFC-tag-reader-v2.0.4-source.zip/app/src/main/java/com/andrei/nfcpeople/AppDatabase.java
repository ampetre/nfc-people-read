package com.andrei.nfcpeople;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

public final class AppDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "nfc_people.db";
    private static final int DB_VERSION = 1;

    public static final String ACTIVE = "ACTIVE";
    public static final String PAUSED = "PAUSED";
    public static final String FINALIZED = "FINALIZED";

    public AppDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "session_date TEXT NOT NULL," +
                "status TEXT NOT NULL," +
                "started_at INTEGER NOT NULL," +
                "finalized_at INTEGER)");
        db.execSQL("CREATE TABLE scans (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "session_id INTEGER NOT NULL," +
                "sequence_number INTEGER NOT NULL," +
                "person_name TEXT NOT NULL," +
                "scanned_at INTEGER NOT NULL," +
                "tag_uid TEXT NOT NULL," +
                "FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE)");
        db.execSQL("CREATE UNIQUE INDEX scan_sequence ON scans(session_id, sequence_number)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 has no migrations.
    }

    public synchronized Session getOpenSession() {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id, session_date, status, started_at, finalized_at " +
                        "FROM sessions WHERE status IN (?, ?) ORDER BY id DESC LIMIT 1",
                new String[]{ACTIVE, PAUSED})) {
            return c.moveToFirst() ? readSession(c) : null;
        }
    }

    public synchronized Session createTodaySession() {
        Session existing = getOpenSession();
        if (existing != null) return existing;
        long now = System.currentTimeMillis();
        ContentValues values = new ContentValues();
        values.put("session_date", LocalDate.now().toString());
        values.put("status", ACTIVE);
        values.put("started_at", now);
        long id = getWritableDatabase().insertOrThrow("sessions", null, values);
        return new Session(id, LocalDate.now().toString(), ACTIVE, now, null);
    }

    public synchronized void setStatus(long sessionId, String status) {
        ContentValues values = new ContentValues();
        values.put("status", status);
        getWritableDatabase().update("sessions", values, "id=?", new String[]{String.valueOf(sessionId)});
    }

    public synchronized Scan insertScan(long sessionId, String personName, long scannedAt, String tagUid) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            int nextSequence = 1;
            try (Cursor c = db.rawQuery(
                    "SELECT COALESCE(MAX(sequence_number), 0) + 1 FROM scans WHERE session_id=?",
                    new String[]{String.valueOf(sessionId)})) {
                if (c.moveToFirst()) nextSequence = c.getInt(0);
            }
            ContentValues values = new ContentValues();
            values.put("session_id", sessionId);
            values.put("sequence_number", nextSequence);
            values.put("person_name", personName);
            values.put("scanned_at", scannedAt);
            values.put("tag_uid", tagUid);
            long id = db.insertOrThrow("scans", null, values); // INSERT only: never overwrites.
            db.setTransactionSuccessful();
            return new Scan(id, sessionId, nextSequence, personName, scannedAt, tagUid);
        } finally {
            db.endTransaction();
        }
    }

    public synchronized List<Scan> getScans(long sessionId) {
        List<Scan> scans = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id, session_id, sequence_number, person_name, scanned_at, tag_uid " +
                        "FROM scans WHERE session_id=? ORDER BY sequence_number ASC",
                new String[]{String.valueOf(sessionId)})) {
            while (c.moveToNext()) {
                scans.add(new Scan(c.getLong(0), c.getLong(1), c.getInt(2), c.getString(3), c.getLong(4), c.getString(5)));
            }
        }
        return scans;
    }

    public synchronized int getScanCount(long sessionId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM scans WHERE session_id=?",
                new String[]{String.valueOf(sessionId)})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public synchronized boolean updateManualScanName(long scanId, String personName) {
        ContentValues values = new ContentValues();
        values.put("person_name", personName);
        int updated = getWritableDatabase().update(
                "scans",
                values,
                "id=? AND tag_uid LIKE ?",
                new String[]{String.valueOf(scanId), "MANUAL:%"});
        return updated == 1;
    }

    public synchronized void deleteScan(long scanId) {
        getWritableDatabase().delete("scans", "id=?", new String[]{String.valueOf(scanId)});
    }

    public synchronized boolean deleteEmptySession(long sessionId) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            int count = 0;
            try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM scans WHERE session_id=?",
                    new String[]{String.valueOf(sessionId)})) {
                if (c.moveToFirst()) count = c.getInt(0);
            }
            if (count != 0) return false;
            int deleted = db.delete("sessions", "id=? AND status IN (?, ?)",
                    new String[]{String.valueOf(sessionId), ACTIVE, PAUSED});
            db.setTransactionSuccessful();
            return deleted == 1;
        } finally {
            db.endTransaction();
        }
    }

    public synchronized void finalizeSession(long sessionId) {
        ContentValues values = new ContentValues();
        values.put("status", FINALIZED);
        values.put("finalized_at", System.currentTimeMillis());
        getWritableDatabase().update("sessions", values, "id=?", new String[]{String.valueOf(sessionId)});
    }

    public synchronized List<Session> getFinalizedSessions() {
        List<Session> sessions = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id, session_date, status, started_at, finalized_at FROM sessions " +
                        "WHERE status=? ORDER BY session_date DESC, id DESC",
                new String[]{FINALIZED})) {
            while (c.moveToNext()) sessions.add(readSession(c));
        }
        return sessions;
    }

    private Session readSession(Cursor c) {
        return new Session(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.isNull(4) ? null : c.getLong(4));
    }

    public record Session(long id, String date, String status, long startedAt, Long finalizedAt) {}
    public record Scan(long id, long sessionId, int sequence, String personName, long scannedAt, String tagUid) {
        public LocalDate localDate() {
            return Instant.ofEpochMilli(scannedAt).atZone(ZoneId.systemDefault()).toLocalDate();
        }
    }
}
