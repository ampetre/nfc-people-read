package com.andrei.nfcpeople;

import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.Tag;
import android.nfc.tech.Ndef;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class NfcNameReader {
    private static final String[] URI_PREFIXES = {
            "", "http://www.", "https://www.", "http://", "https://", "tel:", "mailto:",
            "ftp://anonymous:anonymous@", "ftp://ftp.", "ftps://", "sftp://", "smb://", "nfs://",
            "ftp://", "dav://", "news:", "telnet://", "imap:", "rtsp://", "urn:", "pop:",
            "sip:", "sips:", "tftp:", "btspp://", "btl2cap://", "btgoep://", "tcpobex://",
            "irdaobex://", "file://", "urn:epc:id:", "urn:epc:tag:", "urn:epc:pat:",
            "urn:epc:raw:", "urn:epc:", "urn:nfc:"
    };

    private NfcNameReader() {}

    public static Result read(Tag tag) throws IOException {
        String uid = bytesToHex(tag.getId());
        Ndef ndef = Ndef.get(tag);
        if (ndef == null) throw new IOException("The tag is not NDEF formatted.");

        NdefMessage message;
        ndef.connect();
        try {
            message = ndef.getNdefMessage();
        } catch (FormatException e) {
            throw new IOException("The tag contains malformed NDEF data.", e);
        } finally {
            try { ndef.close(); } catch (Exception ignored) {}
        }
        if (message == null || message.getRecords().length == 0) {
            throw new IOException("The tag contains no readable name.");
        }

        for (NdefRecord record : message.getRecords()) {
            String decoded = decodeRecord(record);
            if (decoded != null) {
                String name = normalizeName(decoded);
                if (!name.isEmpty()) return new Result(name, uid);
            }
        }
        throw new IOException("The tag contains no readable person name.");
    }

    private static String decodeRecord(NdefRecord record) {
        byte[] type = record.getType();
        byte[] payload = record.getPayload();
        if (payload == null || payload.length == 0) return null;

        if (record.getTnf() == NdefRecord.TNF_WELL_KNOWN && java.util.Arrays.equals(type, NdefRecord.RTD_TEXT)) {
            int status = payload[0] & 0xFF;
            int languageLength = status & 0x3F;
            boolean utf16 = (status & 0x80) != 0;
            int start = 1 + languageLength;
            if (start > payload.length) return null;
            Charset charset = utf16 ? StandardCharsets.UTF_16 : StandardCharsets.UTF_8;
            return new String(payload, start, payload.length - start, charset);
        }

        if (record.getTnf() == NdefRecord.TNF_WELL_KNOWN && java.util.Arrays.equals(type, NdefRecord.RTD_URI)) {
            int prefixIndex = payload[0] & 0xFF;
            String prefix = prefixIndex < URI_PREFIXES.length ? URI_PREFIXES[prefixIndex] : "";
            return prefix + new String(payload, 1, payload.length - 1, StandardCharsets.UTF_8);
        }

        String utf8 = new String(payload, StandardCharsets.UTF_8).trim();
        return isMostlyPrintable(utf8) ? utf8 : null;
    }

    private static String normalizeName(String value) {
        return value.replace('\u0000', ' ').replaceAll("\\s+", " ").trim();
    }

    private static boolean isMostlyPrintable(String value) {
        if (value.isBlank()) return false;
        long printable = value.codePoints().filter(cp -> !Character.isISOControl(cp) || Character.isWhitespace(cp)).count();
        return printable >= Math.max(1, value.codePointCount(0, value.length()) * 9L / 10L);
    }

    public static String bytesToHex(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return "UNKNOWN";
        StringBuilder builder = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) builder.append(String.format(Locale.ROOT, "%02X", b));
        return builder.toString();
    }

    public record Result(String personName, String tagUid) {}
}
