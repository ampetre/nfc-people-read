# RoB NFC tag reader 2.0.0

- Manual entries are added directly into the active NFC session list.
- Manual entries can be edited before the session is finalized.
- Any active/paused entry can be deleted after two explicit confirmations.
- Excel includes a Source column: Scan or Manual.
- RoB alphabetical Excel ordering is preserved.
- NFC repeat protection, vibration behavior, session persistence, empty-session close,
  responsive/Fold layout, RoB branding and existing signing identity are preserved.

## v2.0.0 regenerated build

- Internal versionCode: 21
- Delete uses one English confirmation dialog.
- The selected person name is bolded in the confirmation message.
- Upgrade compatibility from RoB v1.8.x and the first v2.0.0 build is preserved.

## v2.0.1

- Single tap on a session row does nothing.
- Long press opens Edit/Delete actions.
- Manual name fields use Android word capitalization and autocorrect.
- Internal versionCode: 22.

## v2.0.2

- Fixes the long-press action dialog on devices/themes where AlertDialog list items were hidden.
- Manual entries now show explicit EDIT NAME and DELETE ENTRY buttons.
- NFC entries show an explicit DELETE ENTRY button.
- Single tap remains disabled.
- Internal versionCode: 23.

## v2.0.3

- Excel title changed to: RoB presence list — DD.MM.YYYY.
- The date is the session/list date.
- No other behavior changed.
- Internal versionCode: 24.

## v2.0.4

- Each editable list row now includes a small action hint.
- NFC rows: Hold for delete entry.
- Manual rows: Hold for edit or delete entry.
- The generic long-press hint above the list was removed.
- Finalized/read-only history rows do not show action hints.
- Internal versionCode: 25.

## v2.0.5

- Remaining entries are renumbered immediately after deleting a row.
- Example: deleting entry 1 from 1,2,3 leaves entries numbered 1,2 rather than 2,3.
- Only the sequence numbering changes; names, timestamps, Scan/Manual source and session data are preserved.
- Internal versionCode: 26.
