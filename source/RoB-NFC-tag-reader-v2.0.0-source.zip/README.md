# RoB NFC tag reader 2.0.0

- Manual entries are added directly into the active NFC session list.
- Manual entries can be edited before the session is finalized.
- Any active/paused entry can be deleted after two explicit confirmations.
- Excel includes a Source column: Scan or Manual.
- RoB alphabetical Excel ordering is preserved.
- NFC repeat protection, vibration behavior, session persistence, empty-session close,
  responsive/Fold layout, RoB branding and existing signing identity are preserved.
