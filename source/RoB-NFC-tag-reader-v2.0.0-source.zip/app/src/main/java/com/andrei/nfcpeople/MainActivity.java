package com.andrei.nfcpeople;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.DisplayCutout;
import android.view.Window;
import android.view.WindowInsets;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity implements NfcAdapter.ReaderCallback {
    private static final int CREATE_XLSX_REQUEST = 7301;
    private static final long REPEAT_GUARD_MS = 2000L;
    private static final int SCREEN_HOME = 0;
    private static final int SCREEN_READER = 1;
    private static final int SCREEN_REVIEW = 2;
    private static final String STATE_SCREEN = "screen";
    private static final String STATE_REVIEW_SESSION = "review_session";
    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault());
    private static final DateTimeFormatter FILE_DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DISPLAY_TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final int blue = Color.rgb(36, 87, 214);
    private final int green = Color.rgb(22, 132, 84);
    private final int red = Color.rgb(180, 45, 55);

    private AppDatabase database;
    private NfcAdapter nfcAdapter;
    private volatile AppDatabase.Session currentSession;
    private volatile boolean readerScreenVisible;
    private int currentScreen = SCREEN_HOME;
    private long reviewSessionId = -1;
    private long pendingExportSessionId = -1;
    private String lastAcceptedTagUid = "";
    private long lastAcceptedTagAt;

    private LinearLayout root;
    private TextView countText;
    private TextView latestName;
    private TextView latestTime;
    private TextView nfcStatusText;
    private Button nfcActionButton;
    private ListView liveReadList;
    private ReadListAdapter liveReadAdapter;
    private final ArrayList<String> liveReadRows = new ArrayList<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private int lastRenderedCount = -1;
    private final Runnable liveRefreshTask = new Runnable() {
        @Override
        public void run() {
            if (!readerScreenVisible || currentScreen != SCREEN_READER) return;
            refreshReaderList();
            mainHandler.postDelayed(this, 350L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();
        database = new AppDatabase(this);
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        currentSession = database.getOpenSession();

        if (savedInstanceState != null) {
            int restoredScreen = savedInstanceState.getInt(STATE_SCREEN, SCREEN_HOME);
            long restoredReviewId = savedInstanceState.getLong(STATE_REVIEW_SESSION, -1);
            if (restoredScreen == SCREEN_READER && currentSession != null) {
                showReader();
                return;
            }
            if (restoredScreen == SCREEN_REVIEW && restoredReviewId > 0) {
                AppDatabase.Session session = findSession(restoredReviewId);
                if (session != null) {
                    showReview(session);
                    return;
                }
            }
        }
        showHome();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SCREEN, currentScreen);
        outState.putLong(STATE_REVIEW_SESSION, reviewSessionId);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (readerScreenVisible) {
            updateNfcUi();
            enableReaderMode();
            refreshReaderList();
            startLiveRefresh();
        } else if (currentScreen == SCREEN_HOME && root != null) {
            // Refresh the NFC state after returning from Samsung settings.
            showHome();
        }
    }

    @Override
    protected void onPause() {
        stopLiveRefresh();
        if (nfcAdapter != null) nfcAdapter.disableReaderMode(this);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopLiveRefresh();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (currentScreen == SCREEN_READER && currentSession != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Pause NFC reading?")
                    .setMessage("Your existing reads will stay saved and can be resumed later.")
                    .setNegativeButton("Keep reading", null)
                    .setPositiveButton("Pause", (dialog, which) -> finishRead())
                    .show();
        } else if (currentScreen == SCREEN_REVIEW) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    private void showHome() {
        currentScreen = SCREEN_HOME;
        reviewSessionId = -1;
        readerScreenVisible = false;
        stopLiveRefresh();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (nfcAdapter != null) nfcAdapter.disableReaderMode(this);
        currentSession = database.getOpenSession();

        root = vertical(responsivePadding());
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root, matchWrap());
        setCenteredScreen(scroll, 760);

        addTitle("RoB NFC tag reader");
        addSubtitle(DISPLAY_DATE.format(LocalDate.now()));
        addSpace(adaptiveSpace(24));

        if (nfcAdapter == null) {
            addCardMessage("NFC is unavailable", "This device does not report NFC hardware.");
            return;
        }
        if (!nfcAdapter.isEnabled()) {
            addCardMessage("NFC is turned off", "Android requires NFC to be enabled from system settings. Return here afterward and the app will detect it automatically.");
            Button settingsButton = primaryButton("ENABLE NFC");
            settingsButton.setOnClickListener(v -> openNfcSettings());
            root.addView(settingsButton);
            addSpace(12);
        }

        if (currentSession == null) {
            addCardMessage("Ready for today", "No reading session has been started. Every tag will append a new person to the list.");
            Button start = primaryButton("START READING");
            start.setOnClickListener(v -> startNewSession());
            root.addView(start);
        } else {
            int count = database.getScanCount(currentSession.id());
            addCardMessage("Today’s session is paused", count + (count == 1 ? " person recorded" : " people recorded") + ". Nothing will be overwritten when reading resumes.");
            Button resume = primaryButton("RESUME READING");
            resume.setOnClickListener(v -> showReader());
            root.addView(resume);
            addSpace(10);
            Button review = secondaryButton("REVIEW LIST");
            review.setOnClickListener(v -> showReview(currentSession));
            root.addView(review);
            addSpace(18);
            Button finishToday = dangerButton(count == 0 ? "CLOSE EMPTY SESSION" : "FINISH FOR TODAY");
            finishToday.setOnClickListener(v -> confirmFinishToday(currentSession));
            root.addView(finishToday);
        }

        List<AppDatabase.Session> history = database.getFinalizedSessions();
        if (!history.isEmpty()) {
            addSpace(28);
            addSection("Previous days");
            for (AppDatabase.Session session : history) {
                int count = database.getScanCount(session.id());
                Button historyButton = secondaryButton(session.date() + "  •  " + count + " reads");
                historyButton.setOnClickListener(v -> showReview(session));
                root.addView(historyButton);
                addSpace(8);
            }
        }
    }

    private void startNewSession() {
        currentSession = database.createTodaySession();
        showReader();
    }

    private void showReader() {
        currentScreen = SCREEN_READER;
        reviewSessionId = -1;
        if (currentSession == null) currentSession = database.createTodaySession();
        database.setStatus(currentSession.id(), AppDatabase.ACTIVE);
        currentSession = new AppDatabase.Session(currentSession.id(), currentSession.date(), AppDatabase.ACTIVE, currentSession.startedAt(), currentSession.finalizedAt());
        readerScreenVisible = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (useTwoPaneLayout()) {
            showReaderTwoPane();
        } else {
            showReaderCompact();
        }
        lastRenderedCount = -1;
        refreshReaderList();
        startLiveRefresh();
        updateNfcUi();
        enableReaderMode();
    }

    private void showReaderCompact() {
        root = vertical(responsivePadding());
        setCenteredScreen(root, 760);

        addReaderStatus(root, false);
        addSpace(adaptiveSpace(10));
        addReaderSummary(root, false);
        addSpace(adaptiveSpace(10));
        Button addManual = secondaryButton("ADD MANUALLY");
        addManual.setOnClickListener(v -> showManualEntryDialog());
        root.addView(addManual, matchWrap());
        addSpace(adaptiveSpace(12));
        addLiveList(root, true);
        addSpace(8);

        Button finishRead = primaryButton("FINISH READ");
        finishRead.setOnClickListener(v -> finishRead());
        LinearLayout.LayoutParams finishParams = matchWrap();
        finishParams.topMargin = dp(6);
        root.addView(finishRead, finishParams);
    }

    private void showReaderTwoPane() {
        LinearLayout split = new LinearLayout(this);
        split.setOrientation(LinearLayout.HORIZONTAL);
        split.setPadding(dp(responsivePadding()), dp(responsivePadding()), dp(responsivePadding()), dp(responsivePadding()));
        split.setBackgroundColor(backgroundColor());
        setCenteredScreen(split, 1280);

        LinearLayout left = vertical(0);
        ScrollView leftScroll = new ScrollView(this);
        leftScroll.setFillViewport(true);
        leftScroll.addView(left, matchWrap());
        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.42f);
        leftParams.setMarginEnd(dp(18));
        split.addView(leftScroll, leftParams);

        addReaderStatus(left, true);
        addSpaceTo(left, 14);
        addReaderSummary(left, true);
        addSpaceTo(left, 12);
        Button addManual = secondaryButton("ADD MANUALLY");
        addManual.setOnClickListener(v -> showManualEntryDialog());
        left.addView(addManual, matchWrap());
        addSpaceTo(left, 10);
        Button finishRead = primaryButton("FINISH READ");
        finishRead.setOnClickListener(v -> finishRead());
        left.addView(finishRead, matchWrap());

        LinearLayout right = vertical(0);
        right.setPadding(dp(18), 0, 0, 0);
        right.setBackground(rounded(surfaceColor(), 18, 1, dividerColor()));
        LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.58f);
        split.addView(right, rightParams);
        addLiveList(right, true);
    }

    private void addReaderStatus(LinearLayout target, boolean expanded) {
        boolean stack = !expanded && (screenWidthDp() < 400 || fontScale() > 1.18f);
        LinearLayout statusBox = new LinearLayout(this);
        statusBox.setOrientation(stack ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        statusBox.setGravity(stack ? Gravity.START : Gravity.CENTER_VERTICAL);
        statusBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        statusBox.setBackground(rounded(surfaceColor(), 16, 1, dividerColor()));

        nfcStatusText = text("●  NFC READER ACTIVE", adaptiveText(14), blue, Typeface.BOLD);
        if (stack) {
            statusBox.addView(nfcStatusText, matchWrap());
            addSpaceTo(statusBox, 8);
        } else {
            statusBox.addView(nfcStatusText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        }

        nfcActionButton = secondaryButton("NFC SETTINGS");
        nfcActionButton.setOnClickListener(v -> openNfcSettings());
        if (stack) {
            statusBox.addView(nfcActionButton, matchWrap());
        } else {
            LinearLayout.LayoutParams settingsParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            settingsParams.setMarginStart(dp(10));
            statusBox.addView(nfcActionButton, settingsParams);
        }
        target.addView(statusBox, matchWrap());
    }

    private void addReaderSummary(LinearLayout target, boolean expanded) {
        target.addView(text("Hold a tag near the phone", adaptiveText(expanded ? 30 : 27), textPrimary(), Typeface.BOLD), matchWrap());
        addSpaceTo(target, 4);
        String instruction = isShortScreen()
                ? "Scan a tag or add a person manually."
                : "Scan NFC tags or add a person manually. Every entry is appended to the same live list.";
        target.addView(text(instruction, adaptiveText(15), textSecondary(), Typeface.NORMAL), matchWrap());
        addSpaceTo(target, adaptiveSpace(14));

        countText = text("0 PEOPLE READ", adaptiveText(expanded ? 28 : 25), textPrimary(), Typeface.BOLD);
        countText.setGravity(expanded ? Gravity.START : Gravity.CENTER);
        target.addView(countText, matchWrap());
        addSpaceTo(target, adaptiveSpace(12));

        LinearLayout latestCard = vertical(adaptiveSpace(14));
        latestCard.setBackground(rounded(surfaceColor(), 18, 1, dividerColor()));
        latestCard.addView(text("LATEST READ", adaptiveText(12), textSecondary(), Typeface.BOLD));
        latestName = text("Waiting for a tag or manual entry…", adaptiveText(expanded ? 24 : 22), textPrimary(), Typeface.BOLD);
        latestCard.addView(latestName, matchWrap());
        latestTime = text("", adaptiveText(15), textSecondary(), Typeface.NORMAL);
        latestCard.addView(latestTime, matchWrap());
        target.addView(latestCard, matchWrap());
    }

    private void addLiveList(LinearLayout target, boolean weighted) {
        target.addView(text("LIVE READ LIST", adaptiveText(14), textSecondary(), Typeface.BOLD), matchWrap());
        target.addView(text("Tap an entry for edit/delete options.", adaptiveText(12), textSecondary(), Typeface.NORMAL), matchWrap());
        addSpaceTo(target, 6);
        liveReadRows.clear();
        liveReadAdapter = new ReadListAdapter(liveReadRows);
        liveReadList = new ListView(this);
        liveReadList.setAdapter(liveReadAdapter);
        liveReadList.setDividerHeight(dp(1));
        liveReadList.setDivider(rounded(dividerColor(), 0, 0, Color.TRANSPARENT));
        liveReadList.setClipToPadding(false);
        liveReadList.setPadding(0, 0, 0, dp(8));
        liveReadList.setMinimumHeight(dp(120));
        liveReadList.setOnItemClickListener((parent, view, position, id) -> {
            AppDatabase.Session session = currentSession;
            if (!readerScreenVisible || currentScreen != SCREEN_READER || session == null) return;
            List<AppDatabase.Scan> scans = database.getScans(session.id());
            int scanIndex = scans.size() - 1 - position;
            if (scanIndex < 0 || scanIndex >= scans.size()) return;
            AppDatabase.Scan scan = scans.get(scanIndex);
            showEntryActions(scan, () -> {
                lastRenderedCount = -1;
                refreshReaderList();
            });
        });
        LinearLayout.LayoutParams listParams = weighted
                ? new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1)
                : matchWrap();
        target.addView(liveReadList, listParams);
    }

    private void showManualEntryDialog() {
        AppDatabase.Session session = currentSession;
        if (!readerScreenVisible || currentScreen != SCREEN_READER || session == null) {
            Toast.makeText(this, "Start or resume a reading session first.", Toast.LENGTH_SHORT).show();
            return;
        }

        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setHint("Person name");
        input.setTextSize(18);

        int horizontalPadding = dp(22);
        FrameLayout inputWrapper = new FrameLayout(this);
        inputWrapper.setPadding(horizontalPadding, 0, horizontalPadding, 0);
        inputWrapper.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add person manually")
                .setMessage("Enter the name exactly as it should appear in this session.")
                .setView(inputWrapper)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("ADD", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            Button add = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            add.setOnClickListener(v -> {
                String personName = input.getText() == null ? "" : input.getText().toString().trim();
                if (personName.isEmpty()) {
                    input.setError("Enter a name");
                    return;
                }

                AppDatabase.Session activeSession = currentSession;
                if (!readerScreenVisible || currentScreen != SCREEN_READER || activeSession == null) {
                    dialog.dismiss();
                    Toast.makeText(this, "The reading session is no longer active.", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    long now = System.currentTimeMillis();
                    AppDatabase.Scan scan = database.insertScan(
                            activeSession.id(),
                            personName,
                            now,
                            "MANUAL:" + now + ":" + SystemClock.elapsedRealtimeNanos());
                    applyScanToLiveUi(scan);
                    dialog.dismiss();
                } catch (Exception exception) {
                    Toast.makeText(this,
                            "Could not add entry: " + exception.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        });

        dialog.show();
        input.requestFocus();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    private boolean isManualEntry(AppDatabase.Scan scan) {
        return scan != null && scan.tagUid() != null && scan.tagUid().startsWith("MANUAL:");
    }

    private void showEntryActions(AppDatabase.Scan scan, Runnable afterChange) {
        if (scan == null) return;
        boolean manual = isManualEntry(scan);
        String source = manual ? "Manual entry" : "NFC scan";
        CharSequence[] actions = manual
                ? new CharSequence[]{"Edit name", "Delete entry"}
                : new CharSequence[]{"Delete entry"};

        new AlertDialog.Builder(this)
                .setTitle(scan.personName())
                .setMessage(source + " • " + formatTime(scan.scannedAt()))
                .setItems(actions, (dialog, which) -> {
                    if (manual && which == 0) {
                        showEditManualEntryDialog(scan, afterChange);
                    } else {
                        confirmDeleteEntry(scan, afterChange);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditManualEntryDialog(AppDatabase.Scan scan, Runnable afterChange) {
        if (!isManualEntry(scan)) {
            Toast.makeText(this, "Only manually added entries can be edited.", Toast.LENGTH_SHORT).show();
            return;
        }

        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setHint("Person name");
        input.setText(scan.personName());
        input.setSelection(input.getText().length());
        input.setTextSize(18);

        int horizontalPadding = dp(22);
        FrameLayout inputWrapper = new FrameLayout(this);
        inputWrapper.setPadding(horizontalPadding, 0, horizontalPadding, 0);
        inputWrapper.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit manual entry")
                .setMessage("The original entry time and Manual source are preserved.")
                .setView(inputWrapper)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            Button save = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            save.setOnClickListener(v -> {
                String personName = input.getText() == null ? "" : input.getText().toString().trim();
                if (personName.isEmpty()) {
                    input.setError("Enter a name");
                    return;
                }
                if (personName.equals(scan.personName())) {
                    dialog.dismiss();
                    return;
                }
                if (!database.updateManualScanName(scan.id(), personName)) {
                    Toast.makeText(this, "The manual entry could not be updated.", Toast.LENGTH_LONG).show();
                    return;
                }
                dialog.dismiss();
                if (afterChange != null) afterChange.run();
                Toast.makeText(this, "Manual entry updated.", Toast.LENGTH_SHORT).show();
            });
        });

        dialog.show();
        input.requestFocus();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    private void confirmDeleteEntry(AppDatabase.Scan scan, Runnable afterChange) {
        String personName = scan.personName() == null ? "" : scan.personName();
        String prefix = "Do you want to remove the name \"";
        String suffix = "\" from the list?";

        SpannableStringBuilder message = new SpannableStringBuilder();
        message.append(prefix);
        int nameStart = message.length();
        message.append(personName);
        int nameEnd = message.length();
        message.setSpan(
                new StyleSpan(Typeface.BOLD),
                nameStart,
                nameEnd,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        message.append(suffix);

        new AlertDialog.Builder(this)
                .setTitle("Confirm deletion")
                .setMessage(message)
                .setNegativeButton("No", null)
                .setPositiveButton("Yes, remove it from the list", (dialog, which) -> {
                    database.deleteScan(scan.id());

                    // If a scanned entry is corrected by deleting it, allow the
                    // same tag to be presented again immediately.
                    if (!isManualEntry(scan)) {
                        synchronized (this) {
                            if (scan.tagUid() != null
                                    && scan.tagUid().equals(lastAcceptedTagUid)) {
                                lastAcceptedTagUid = "";
                                lastAcceptedTagAt = 0L;
                            }
                        }
                    }

                    if (afterChange != null) afterChange.run();
                    Toast.makeText(this, "Entry removed from the list.", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void finishRead() {
        if (currentSession != null) database.setStatus(currentSession.id(), AppDatabase.PAUSED);
        readerScreenVisible = false;
        stopLiveRefresh();
        if (nfcAdapter != null) nfcAdapter.disableReaderMode(this);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showHome();
    }

    @Override
    public void onTagDiscovered(Tag tag) {
        try {
            NfcNameReader.Result result = NfcNameReader.read(tag);
            long sessionId = currentSession == null ? -1 : currentSession.id();
            if (sessionId < 0 || !readerScreenVisible) return;

            // Suppress only an immediate repeat callback from the exact same tag. A different
            // UID is always accepted, even when it is presented in the very next second.
            long acceptedAt = SystemClock.elapsedRealtime();
            synchronized (this) {
                if (result.tagUid().equals(lastAcceptedTagUid)
                        && acceptedAt - lastAcceptedTagAt < REPEAT_GUARD_MS) {
                    return;
                }
                lastAcceptedTagUid = result.tagUid();
                lastAcceptedTagAt = acceptedAt;
            }

            AppDatabase.Scan scan;
            try {
                scan = database.insertScan(sessionId, result.personName(),
                        System.currentTimeMillis(), result.tagUid());
            } catch (Exception insertFailure) {
                // Do not let a failed insert block a valid retry of the same tag.
                synchronized (this) {
                    if (result.tagUid().equals(lastAcceptedTagUid)
                            && lastAcceptedTagAt == acceptedAt) {
                        lastAcceptedTagUid = "";
                        lastAcceptedTagAt = 0L;
                    }
                }
                throw insertFailure;
            }
            mainHandler.post(() -> applyScanToLiveUi(scan));
        } catch (Exception exception) {
            runOnUiThread(() -> Toast.makeText(this, exception.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void applyScanToLiveUi(AppDatabase.Scan scan) {
        if (!readerScreenVisible || currentScreen != SCREEN_READER) return;
        if (latestName != null) {
            latestName.setText("✓  " + scan.personName());
            latestName.setTextColor(green);
        }
        if (latestTime != null) latestTime.setText(formatTime(scan.scannedAt()));

        // Update immediately from the inserted row. The periodic refresh below remains
        // as a safety net for lifecycle, Samsung NFC thread, rotation and fold transitions.
        if (liveReadAdapter != null && liveReadList != null) {
            liveReadRows.add(0, formatLiveRow(scan));
            liveReadAdapter.notifyDataSetChanged();
            liveReadList.setSelection(0);
        }
        int count = database.getScanCount(scan.sessionId());
        updateCountText(count);
        lastRenderedCount = count;

        // Platform NFC feedback is disabled. Vibrate only after the new row is visible and the
        // counter has been updated, so failed/ignored reads do not produce success feedback.
        vibrateSuccess();
    }

    private void refreshReaderList() {
        AppDatabase.Session session = currentSession;
        if (!readerScreenVisible || session == null || liveReadAdapter == null || countText == null) return;
        List<AppDatabase.Scan> scans = database.getScans(session.id());
        int count = scans.size();
        updateCountText(count);

        // Avoid rebuilding the adapter every 350 ms when nothing changed.
        if (count == lastRenderedCount && liveReadRows.size() == count) return;
        liveReadRows.clear();
        for (int i = scans.size() - 1; i >= 0; i--) {
            liveReadRows.add(formatLiveRow(scans.get(i)));
        }
        liveReadAdapter.notifyDataSetChanged();
        if (!liveReadRows.isEmpty() && liveReadList != null) liveReadList.setSelection(0);

        if (latestName != null && latestTime != null) {
            if (scans.isEmpty()) {
                latestName.setText("Waiting for a tag or manual entry…");
                latestName.setTextColor(textPrimary());
                latestTime.setText("");
            } else {
                AppDatabase.Scan latest = scans.get(scans.size() - 1);
                latestName.setText("✓  " + latest.personName());
                latestName.setTextColor(green);
                latestTime.setText(formatTime(latest.scannedAt()));
            }
        }
        lastRenderedCount = count;
    }

    private String formatLiveRow(AppDatabase.Scan scan) {
        return scan.sequence() + ".  " + scan.personName() + "\n" + formatTime(scan.scannedAt());
    }

    private void updateCountText(int count) {
        if (countText != null) {
            countText.setText(count + (count == 1 ? " PERSON READ" : " PEOPLE READ"));
        }
    }

    private void startLiveRefresh() {
        mainHandler.removeCallbacks(liveRefreshTask);
        if (readerScreenVisible && currentScreen == SCREEN_READER) {
            mainHandler.post(liveRefreshTask);
        }
    }

    private void stopLiveRefresh() {
        mainHandler.removeCallbacks(liveRefreshTask);
    }

    private void showReview(AppDatabase.Session session) {
        currentScreen = SCREEN_REVIEW;
        reviewSessionId = session.id();
        readerScreenVisible = false;
        stopLiveRefresh();
        if (nfcAdapter != null) nfcAdapter.disableReaderMode(this);
        List<AppDatabase.Scan> scans = database.getScans(session.id());

        LinearLayout page = vertical(responsivePadding());
        setCenteredScreen(page, 920);
        addTitleTo(page, session.status().equals(AppDatabase.FINALIZED) ? "Finalized list" : "Today’s readings");
        page.addView(text(session.date() + "  •  " + scans.size() + " entries", adaptiveText(15), textSecondary(), Typeface.NORMAL));
        addSpaceTo(page, adaptiveSpace(12));

        ArrayList<String> lines = new ArrayList<>();
        for (AppDatabase.Scan scan : scans) {
            lines.add(scan.sequence() + ".  " + scan.personName() + "\n" + formatTime(scan.scannedAt()));
        }
        ListView list = new ListView(this);
        ReadListAdapter adapter = new ReadListAdapter(lines);
        list.setAdapter(adapter);
        list.setDividerHeight(dp(1));
        page.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        if (!session.status().equals(AppDatabase.FINALIZED)) {
            list.setOnItemClickListener((parent, view, position, id) -> {
                if (position < 0 || position >= scans.size()) return;
                AppDatabase.Scan scan = scans.get(position);
                showEntryActions(scan, () -> showReview(session));
            });
        }

        addReviewActions(page, session, scans.isEmpty());
    }

    private void addReviewActions(LinearLayout page, AppDatabase.Session session, boolean empty) {
        boolean horizontal = useTwoPaneLayout() && fontScale() <= 1.18f;
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(horizontal ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        actions.setPadding(0, dp(12), 0, 0);

        ArrayList<Button> buttons = new ArrayList<>();
        if (!session.status().equals(AppDatabase.FINALIZED)) {
            Button resume = primaryButton("RESUME READING");
            resume.setOnClickListener(v -> {
                currentSession = session;
                showReader();
            });
            buttons.add(resume);

            Button finish = dangerButton(empty ? "CLOSE EMPTY SESSION" : "FINISH FOR TODAY");
            finish.setOnClickListener(v -> confirmFinishToday(session));
            buttons.add(finish);
        } else {
            Button exportAgain = primaryButton("EXPORT AGAIN");
            exportAgain.setOnClickListener(v -> requestExport(session));
            buttons.add(exportAgain);
        }

        Button back = secondaryButton("BACK");
        back.setOnClickListener(v -> showHome());
        buttons.add(back);

        for (int i = 0; i < buttons.size(); i++) {
            Button button = buttons.get(i);
            if (horizontal) {
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                if (i > 0) params.setMarginStart(dp(8));
                actions.addView(button, params);
            } else {
                actions.addView(button, matchWrap());
            }
        }
        page.addView(actions, matchWrap());
    }

    private void confirmFinishToday(AppDatabase.Session session) {
        int count = database.getScanCount(session.id());
        if (count == 0) {
            new AlertDialog.Builder(this)
                    .setTitle("Close empty session?")
                    .setMessage("No NFC tags were added. The empty session will be closed without creating an Excel file.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Close session", (dialog, which) -> {
                        if (!database.deleteEmptySession(session.id())) {
                            Toast.makeText(this, "The session is no longer empty. Review it before closing.", Toast.LENGTH_LONG).show();
                            showHome();
                            return;
                        }
                        if (currentSession != null && currentSession.id() == session.id()) currentSession = null;
                        currentSession = database.getOpenSession();
                        Toast.makeText(this, "Empty session closed.", Toast.LENGTH_SHORT).show();
                        showHome();
                    })
                    .show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Finish for today?")
                .setMessage(count + (count == 1 ? " person will" : " people will") + " be exported to an Excel workbook. The day will be finalized only after the file is saved successfully.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Choose save location", (dialog, which) -> requestExport(session))
                .show();
    }

    private void requestExport(AppDatabase.Session session) {
        pendingExportSessionId = session.id();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        LocalDate date = LocalDate.parse(session.date());
        intent.putExtra(Intent.EXTRA_TITLE, "RoB_NFC_tag_reader_" + FILE_DATE.format(date) + ".xlsx");
        try {
            startActivityForResult(intent, CREATE_XLSX_REQUEST);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No document provider is available.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_XLSX_REQUEST || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        long sessionId = pendingExportSessionId;
        AppDatabase.Session session = findSession(sessionId);
        if (session == null) {
            Toast.makeText(this, "The session could not be found.", Toast.LENGTH_LONG).show();
            return;
        }
        File stagedWorkbook = null;
        try {
            byte[] workbook = XlsxExporter.create(LocalDate.parse(session.date()), database.getScans(session.id()));
            XlsxExporter.validate(workbook);

            // Build and validate locally first. Document providers can be pipe-backed or remote,
            // where random-access rwt mode and FileDescriptor.sync() are not supported.
            stagedWorkbook = File.createTempFile("nfc-people-export-", ".xlsx", getCacheDir());
            try (FileOutputStream localOutput = new FileOutputStream(stagedWorkbook, false)) {
                localOutput.write(workbook);
                localOutput.flush();
                localOutput.getFD().sync();
            }
            XlsxExporter.validate(readAllBytes(stagedWorkbook));

            writeStagedWorkbook(uri, stagedWorkbook);

            if (!session.status().equals(AppDatabase.FINALIZED)) database.finalizeSession(session.id());
            currentSession = database.getOpenSession();
            new AlertDialog.Builder(this)
                    .setTitle("Export completed")
                    .setMessage(database.getScanCount(session.id()) + " readings were saved successfully.")
                    .setPositiveButton("Done", (dialog, which) -> showHome())
                    .show();
        } catch (Exception exception) {
            String detail = exception.getMessage();
            if (detail == null || detail.trim().isEmpty()) detail = exception.getClass().getSimpleName();
            new AlertDialog.Builder(this)
                    .setTitle("Export failed")
                    .setMessage(detail + "\n\nThe session remains open and no readings were lost.")
                    .setPositiveButton("OK", null)
                    .show();
        } finally {
            if (stagedWorkbook != null && stagedWorkbook.exists()) stagedWorkbook.delete();
            pendingExportSessionId = 0L;
        }
    }

    private void writeStagedWorkbook(Uri uri, File stagedWorkbook) throws IOException {
        OutputStream providerOutput = null;
        try {
            // Prefer write+truncate. Some Samsung/cloud providers reject that mode, so use the
            // standard write mode as a compatibility fallback for ACTION_CREATE_DOCUMENT URIs.
            try {
                providerOutput = getContentResolver().openOutputStream(uri, "wt");
            } catch (Exception ignored) {
                providerOutput = null;
            }
            if (providerOutput == null) providerOutput = getContentResolver().openOutputStream(uri, "w");
            if (providerOutput == null) throw new IOException("The selected destination could not be opened for writing.");

            try (InputStream input = new FileInputStream(stagedWorkbook);
                 OutputStream output = providerOutput) {
                byte[] buffer = new byte[32 * 1024];
                int read;
                while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                output.flush();
            }
        } catch (SecurityException exception) {
            throw new IOException("The selected folder did not grant permission to save the Excel file.", exception);
        }
    }

    private static byte[] readAllBytes(File file) throws IOException {
        try (InputStream input = new FileInputStream(file)) {
            ByteArrayOutputStream output = new ByteArrayOutputStream((int) Math.min(file.length(), 1024 * 1024));
            byte[] buffer = new byte[16 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            return output.toByteArray();
        }
    }

    private AppDatabase.Session findSession(long id) {
        AppDatabase.Session open = database.getOpenSession();
        if (open != null && open.id() == id) return open;
        for (AppDatabase.Session session : database.getFinalizedSessions()) {
            if (session.id() == id) return session;
        }
        return null;
    }

    private void enableReaderMode() {
        if (!readerScreenVisible || nfcAdapter == null || !nfcAdapter.isEnabled()) return;
        Bundle options = new Bundle();
        options.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250);
        int flags = NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_NFC_B |
                NfcAdapter.FLAG_READER_NFC_F | NfcAdapter.FLAG_READER_NFC_V |
                NfcAdapter.FLAG_READER_NFC_BARCODE |
                NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS;
        nfcAdapter.enableReaderMode(this, this, flags, options);
    }

    private void updateNfcUi() {
        if (nfcStatusText == null || nfcActionButton == null) return;
        if (nfcAdapter == null) {
            nfcStatusText.setText("NFC UNAVAILABLE");
            nfcStatusText.setTextColor(red);
            nfcActionButton.setText("NFC UNAVAILABLE");
            nfcActionButton.setEnabled(false);
        } else if (nfcAdapter.isEnabled()) {
            nfcStatusText.setText("●  NFC READER ACTIVE");
            nfcStatusText.setTextColor(blue);
            nfcActionButton.setText("NFC SETTINGS");
            nfcActionButton.setEnabled(true);
        } else {
            nfcStatusText.setText("○  NFC IS OFF");
            nfcStatusText.setTextColor(red);
            nfcActionButton.setText("ENABLE NFC");
            nfcActionButton.setEnabled(true);
        }
    }

    private void openNfcSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_NFC_SETTINGS));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    }

    private void vibrateSuccess() {
        VibrationEffect effect = VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE);
        if (Build.VERSION.SDK_INT >= 31) {
            VibratorManager manager = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
            manager.getDefaultVibrator().vibrate(effect);
        } else {
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            vibrator.vibrate(effect);
        }
    }

    private String formatTime(long millis) {
        return DISPLAY_TIME.format(java.time.Instant.ofEpochMilli(millis)
                .atZone(java.time.ZoneId.systemDefault()).toLocalTime());
    }

    private LinearLayout vertical(int paddingDp) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(paddingDp), dp(paddingDp), dp(paddingDp), dp(paddingDp));
        layout.setBackgroundColor(backgroundColor());
        return layout;
    }

    private void setCenteredScreen(View content, int maxWidthDp) {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(backgroundColor());
        frame.setClipToPadding(false);

        LinearLayout screenColumn = vertical(0);
        screenColumn.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        screenColumn.addView(createAppFooter(), matchWrap());

        int availableWidth = getResources().getDisplayMetrics().widthPixels;
        int desiredWidth = Math.min(availableWidth, dp(maxWidthDp));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(desiredWidth, ViewGroup.LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER_HORIZONTAL;
        frame.addView(screenColumn, params);

        frame.setOnApplyWindowInsetsListener((view, insets) -> {
            int left;
            int top;
            int right;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets safe = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = safe.left;
                top = safe.top;
                right = safe.right;
                bottom = safe.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
                if (Build.VERSION.SDK_INT >= 28) {
                    DisplayCutout cutout = insets.getDisplayCutout();
                    if (cutout != null) {
                        left = Math.max(left, cutout.getSafeInsetLeft());
                        top = Math.max(top, cutout.getSafeInsetTop());
                        right = Math.max(right, cutout.getSafeInsetRight());
                        bottom = Math.max(bottom, cutout.getSafeInsetBottom());
                    }
                }
            }

            int breathingRoom = dp(4);
            view.setPadding(left, top + breathingRoom, right, bottom + breathingRoom);
            int usableWidth = Math.max(1,
                    getResources().getDisplayMetrics().widthPixels - left - right);
            FrameLayout.LayoutParams safeParams = (FrameLayout.LayoutParams) screenColumn.getLayoutParams();
            safeParams.width = Math.min(usableWidth, dp(maxWidthDp));
            safeParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
            safeParams.gravity = Gravity.CENTER_HORIZONTAL;
            screenColumn.setLayoutParams(safeParams);
            return insets;
        });

        setContentView(frame);
        frame.requestApplyInsets();
    }

    private TextView createAppFooter() {
        TextView footer = text("Version 2.0.0  •  © andreimariuspetre",
                adaptiveText(11), textSecondary(), Typeface.NORMAL);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(8), dp(8), dp(6));
        footer.setSingleLine(false);
        return footer;
    }

    private void configureSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(backgroundColor());
        window.setNavigationBarColor(backgroundColor());
        if (Build.VERSION.SDK_INT >= 28) {
            window.setNavigationBarDividerColor(backgroundColor());
        }

        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (!dark()) {
            if (Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        window.getDecorView().setSystemUiVisibility(flags);
    }

    private void addTitle(String value) {
        root.addView(text(value, adaptiveText(31), textPrimary(), Typeface.BOLD));
    }

    private void addTitleTo(LinearLayout target, String value) {
        target.addView(text(value, adaptiveText(29), textPrimary(), Typeface.BOLD));
    }

    private void addSubtitle(String value) {
        root.addView(text(value, adaptiveText(16), textSecondary(), Typeface.NORMAL));
    }

    private void addSection(String value) {
        root.addView(text(value, adaptiveText(14), textSecondary(), Typeface.BOLD));
        addSpace(8);
    }

    private void addSpace(int value) {
        addSpaceTo(root, value);
    }

    private void addSpaceTo(LinearLayout target, int value) {
        Space space = new Space(this);
        target.addView(space, new LinearLayout.LayoutParams(1, dp(value)));
    }

    private void addCardMessage(String title, String message) {
        LinearLayout card = vertical(adaptiveSpace(18));
        card.setBackground(rounded(surfaceColor(), 18, 1, dividerColor()));
        card.addView(text(title, adaptiveText(21), textPrimary(), Typeface.BOLD));
        addSpaceTo(card, 7);
        card.addView(text(message, adaptiveText(16), textSecondary(), Typeface.NORMAL));
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = dp(adaptiveSpace(18));
        root.addView(card, params);
    }

    private Button primaryButton(String label) {
        return styledButton(label, blue, Color.WHITE);
    }

    private Button dangerButton(String label) {
        return styledButton(label, red, Color.WHITE);
    }

    private Button secondaryButton(String label) {
        return styledButton(label, surfaceColor(), textPrimary());
    }

    private Button styledButton(String label, int background, int foreground) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(adaptiveText(15));
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(foreground);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(isShortScreen() ? 46 : 52));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        button.setBackground(rounded(background, 14, background == surfaceColor() ? 1 : 0, dividerColor()));
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = dp(10);
        button.setLayoutParams(params);
        return button;
    }

    private TextView text(String value, int sizeSp, int color, int style) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, style);
        view.setLineSpacing(0, 1.08f);
        view.setBreakStrategy(Build.VERSION.SDK_INT >= 23 ? android.text.Layout.BREAK_STRATEGY_HIGH_QUALITY : 0);
        return view;
    }

    private GradientDrawable rounded(int fill, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private boolean useTwoPaneLayout() {
        return screenWidthDp() >= 600;
    }

    private boolean isShortScreen() {
        return screenHeightDp() < 500;
    }

    private int responsivePadding() {
        int width = screenWidthDp();
        if (width < 360) return 12;
        if (width < 600) return 18;
        return 26;
    }

    private int adaptiveSpace(int normal) {
        return isShortScreen() ? Math.max(6, Math.round(normal * 0.72f)) : normal;
    }

    private int adaptiveText(int normal) {
        if (screenWidthDp() < 330) return Math.max(12, normal - 2);
        return normal;
    }

    private int screenWidthDp() {
        Configuration configuration = getResources().getConfiguration();
        return configuration.screenWidthDp;
    }

    private int screenHeightDp() {
        Configuration configuration = getResources().getConfiguration();
        return configuration.screenHeightDp;
    }

    private float fontScale() {
        return getResources().getConfiguration().fontScale;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private boolean dark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private int backgroundColor() {
        return dark() ? Color.rgb(16, 19, 24) : Color.rgb(246, 248, 252);
    }

    private int surfaceColor() {
        return dark() ? Color.rgb(31, 35, 42) : Color.WHITE;
    }

    private int textPrimary() {
        return dark() ? Color.rgb(241, 243, 247) : Color.rgb(27, 31, 38);
    }

    private int textSecondary() {
        return dark() ? Color.rgb(181, 187, 199) : Color.rgb(91, 99, 113);
    }

    private int dividerColor() {
        return dark() ? Color.rgb(61, 67, 77) : Color.rgb(218, 223, 232);
    }

    private final class ReadListAdapter extends BaseAdapter {
        private final List<String> rows;

        private ReadListAdapter(List<String> rows) {
            this.rows = rows;
        }

        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public String getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView row;
            if (convertView instanceof TextView) {
                row = (TextView) convertView;
            } else {
                row = new TextView(MainActivity.this);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                row.setMinHeight(dp(54));
                row.setLineSpacing(0, 1.10f);
            }
            row.setText(getItem(position));
            row.setTextSize(adaptiveText(16));
            row.setTextColor(textPrimary());
            row.setBackgroundColor(Color.TRANSPARENT);
            return row;
        }
    }
}
