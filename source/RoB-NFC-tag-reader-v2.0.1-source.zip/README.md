# RoB NFC tag reader 2.0.0

- Manual entries are added directly into the active NFC session list.
- Manual entries can be edited before the session is finalized.
- Any active/paused entry can be deleted after two explicit confirmations.
- Excel includes a Source column: Scan or Manual.
- RoB alphabetical Excel ordering is preserved.
- NFC repeat protection, vibration behavior, session persistence, empty-session close,
  responsive/Fold layout, RoB branding and existing signing identity are preserved.

## v2.0.0 regenerated build

- Internal versionCode: 21
- Delete uses one English confirmation dialog.
- The selected person name is bolded in the confirmation message.
- Upgrade compatibility from RoB v1.8.x and the first v2.0.0 build is preserved.

## v2.0.1

- Single tap on a session row does nothing.
- Long press opens Edit/Delete actions.
- Manual name fields use Android word capitalization and autocorrect.
- Internal versionCode: 22.
