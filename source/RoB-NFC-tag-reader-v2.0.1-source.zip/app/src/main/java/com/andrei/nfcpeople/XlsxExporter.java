package com.andrei.nfcpeople;

import org.w3c.dom.Document;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilderFactory;

public final class XlsxExporter {
    private static final DateTimeFormatter TITLE_DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final Set<String> REQUIRED_PARTS = new HashSet<>(Arrays.asList(
            "[Content_Types].xml", "_rels/.rels", "xl/workbook.xml",
            "xl/_rels/workbook.xml.rels", "xl/styles.xml", "xl/sharedStrings.xml",
            "xl/worksheets/sheet1.xml"
    ));

    private XlsxExporter() {}

    public static byte[] create(LocalDate sessionDate, List<AppDatabase.Scan> scans) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream(8192);
        write(output, sessionDate, scans);
        return output.toByteArray();
    }

    public static void write(OutputStream destination, LocalDate sessionDate,
                             List<AppDatabase.Scan> scans) throws IOException {
        SharedStrings strings = new SharedStrings();
        String worksheet = sheet(sessionDate, scans, strings);

        try (ZipOutputStream zip = new ZipOutputStream(destination, StandardCharsets.UTF_8)) {
            put(zip, "[Content_Types].xml", contentTypes());
            put(zip, "_rels/.rels", rootRelationships());
            put(zip, "xl/workbook.xml", workbook(sessionDate));
            put(zip, "xl/_rels/workbook.xml.rels", workbookRelationships());
            put(zip, "xl/styles.xml", styles());
            put(zip, "xl/sharedStrings.xml", strings.toXml());
            put(zip, "xl/worksheets/sheet1.xml", worksheet);
            zip.finish();
        }
    }

    public static void validate(byte[] workbook) throws Exception {
        Set<String> found = new HashSet<>();
        String worksheet = null;
        try (ZipInputStream zip = new ZipInputStream(
                new ByteArrayInputStream(workbook), StandardCharsets.UTF_8)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                found.add(entry.getName());
                byte[] content = readCurrentEntry(zip);
                if (entry.getName().equals("xl/worksheets/sheet1.xml")) {
                    worksheet = new String(content, StandardCharsets.UTF_8);
                }
                if (entry.getName().endsWith(".xml") || entry.getName().endsWith(".rels")) {
                    String xmlText = new String(content, StandardCharsets.UTF_8);
                    if (xmlText.contains("<!DOCTYPE")) {
                        throw new IOException("Unsafe Excel XML part: " + entry.getName());
                    }
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    factory.setNamespaceAware(true);
                    factory.setExpandEntityReferences(false);
                    try {
                        factory.setXIncludeAware(false);
                    } catch (UnsupportedOperationException ignored) {
                        // Not exposed by every Android parser implementation.
                    }
                    Document document = factory.newDocumentBuilder().parse(
                            new ByteArrayInputStream(content));
                    if (document.getDocumentElement() == null) {
                        throw new IOException("Invalid Excel XML part: " + entry.getName());
                    }
                }
                zip.closeEntry();
            }
        }
        if (!found.containsAll(REQUIRED_PARTS)) {
            Set<String> missing = new HashSet<>(REQUIRED_PARTS);
            missing.removeAll(found);
            throw new IOException("Incomplete Excel workbook. Missing: " + missing);
        }
        if (worksheet == null || !worksheet.contains("<sheetData>")) {
            throw new IOException("Invalid Excel worksheet data.");
        }
        // SpreadsheetML children are ordered. In particular, mergeCells must never precede
        // autoFilter. The exporter intentionally omits autoFilter, but keep this guard to prevent
        // a future schema-invalid package that Excel would need to repair.
        int filter = worksheet.indexOf("<autoFilter");
        int merges = worksheet.indexOf("<mergeCells");
        if (filter >= 0 && merges >= 0 && filter > merges) {
            throw new IOException("Invalid Excel worksheet element order.");
        }
    }

    private static byte[] readCurrentEntry(ZipInputStream zip) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream(4096);
        byte[] buffer = new byte[4096];
        int read;
        while ((read = zip.read(buffer)) != -1) output.write(buffer, 0, read);
        return output.toByteArray();
    }

    private static void put(ZipOutputStream zip, String path, String text) throws IOException {
        ZipEntry entry = new ZipEntry(path);
        entry.setTime(0L);
        zip.putNextEntry(entry);
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String sheet(LocalDate date, List<AppDatabase.Scan> scans,
                                SharedStrings strings) {
        List<AppDatabase.Scan> orderedScans = sortedForExport(scans);
        StringBuilder xml = new StringBuilder(4096 + orderedScans.size() * 180);
        int lastRow = orderedScans.size() + 2;
        xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                .append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
                .append("<dimension ref=\"A1:E").append(Math.max(2, lastRow)).append("\"/>")
                .append("<sheetViews><sheetView tabSelected=\"1\" workbookViewId=\"0\">")
                .append("<pane xSplit=\"0\" ySplit=\"2\" topLeftCell=\"A3\" activePane=\"bottomLeft\" state=\"frozen\"/>")
                .append("<selection pane=\"topLeft\" activeCell=\"A1\" sqref=\"A1\"/>")
                .append("<selection pane=\"bottomLeft\" activeCell=\"A3\" sqref=\"A3\"/>")
                .append("</sheetView></sheetViews>")
                .append("<sheetFormatPr baseColWidth=\"10\" defaultRowHeight=\"15\"/>")
                .append("<cols><col min=\"1\" max=\"1\" width=\"8\" customWidth=\"1\"/>")
                .append("<col min=\"2\" max=\"2\" width=\"34\" customWidth=\"1\"/>")
                .append("<col min=\"3\" max=\"4\" width=\"15\" customWidth=\"1\"/><col min=\"5\" max=\"5\" width=\"12\" customWidth=\"1\"/></cols>")
                .append("<sheetData>")
                .append("<row r=\"1\" ht=\"26\" customHeight=\"1\">")
                .append(sharedCell("A1", strings.index("NFC People — " + TITLE_DATE.format(date)), 1))
                .append("</row>")
                .append("<row r=\"2\" ht=\"22\" customHeight=\"1\">")
                .append(sharedCell("A2", strings.index("No."), 2))
                .append(sharedCell("B2", strings.index("Person name"), 2))
                .append(sharedCell("C2", strings.index("Scan date"), 2))
                .append(sharedCell("D2", strings.index("Scan time"), 2))
                .append(sharedCell("E2", strings.index("Source"), 2)).append("</row>");

        ZoneId zone = ZoneId.systemDefault();
        int row = 3;
        int exportNumber = 1;
        for (AppDatabase.Scan scan : orderedScans) {
            var local = Instant.ofEpochMilli(scan.scannedAt()).atZone(zone);
            xml.append("<row r=\"").append(row).append("\">")
                    .append(numberCell("A" + row, exportNumber++, 3))
                    .append(sharedCell("B" + row, strings.index(scan.personName()), 3))
                    .append(sharedCell("C" + row,
                            strings.index(TITLE_DATE.format(local.toLocalDate())), 3))
                    .append(sharedCell("D" + row,
                            strings.index(TIME.format(local.toLocalTime())), 3))
                    .append(sharedCell("E" + row, strings.index(sourceLabel(scan)), 3))
                    .append("</row>");
            row++;
        }
        xml.append("</sheetData>")
                .append("<mergeCells count=\"1\"><mergeCell ref=\"A1:E1\"/></mergeCells>")
                .append("<pageMargins left=\"0.3\" right=\"0.3\" top=\"0.5\" bottom=\"0.5\" header=\"0.2\" footer=\"0.2\"/>")
                .append("</worksheet>");
        return xml.toString();
    }

    static List<AppDatabase.Scan> sortedForExport(List<AppDatabase.Scan> scans) {
        List<AppDatabase.Scan> ordered = new ArrayList<>(scans);
        Collator collator = Collator.getInstance(Locale.forLanguageTag("ro-RO"));
        collator.setStrength(Collator.SECONDARY); // Ignore case, retain Romanian diacritics.
        collator.setDecomposition(Collator.CANONICAL_DECOMPOSITION);
        ordered.sort((left, right) -> {
            int byName = collator.compare(sortName(left.personName()), sortName(right.personName()));
            if (byName != 0) return byName;
            int byTime = Long.compare(left.scannedAt(), right.scannedAt());
            if (byTime != 0) return byTime;
            return Integer.compare(left.sequence(), right.sequence());
        });
        return ordered;
    }

    private static String sortName(String value) {
        return value == null ? "" : value.trim();
    }

    static String sourceLabel(AppDatabase.Scan scan) {
        String uid = scan == null ? null : scan.tagUid();
        return uid != null && uid.startsWith("MANUAL:") ? "Manual" : "Scan";
    }

    private static String sharedCell(String ref, int index, int style) {
        return "<c r=\"" + ref + "\" s=\"" + style + "\" t=\"s\"><v>" + index + "</v></c>";
    }

    private static String numberCell(String ref, int value, int style) {
        return "<c r=\"" + ref + "\" s=\"" + style + "\" t=\"n\"><v>" + value + "</v></c>";
    }

    static String escapeXmlText(String value) {
        if (value == null) return "";
        StringBuilder clean = new StringBuilder(value.length());
        value.codePoints().forEach(cp -> {
            if (cp == 0x9 || cp == 0xA || cp == 0xD
                    || (cp >= 0x20 && cp <= 0xD7FF)
                    || (cp >= 0xE000 && cp <= 0xFFFD)
                    || (cp >= 0x10000 && cp <= 0x10FFFF)) {
                clean.appendCodePoint(cp);
            }
        });
        return clean.toString().replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                + "<Override PartName=\"/xl/sharedStrings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml\"/>"
                + "</Types>";
    }

    private static String rootRelationships() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                + "</Relationships>";
    }

    private static String workbook(LocalDate date) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                + "<bookViews><workbookView activeTab=\"0\" firstSheet=\"0\"/></bookViews>"
                + "<sheets><sheet name=\"" + TITLE_DATE.format(date)
                + "\" sheetId=\"1\" state=\"visible\" r:id=\"rId1\"/></sheets>"
                + "</workbook>";
    }

    private static String workbookRelationships() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
                + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>"
                + "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\" Target=\"sharedStrings.xml\"/>"
                + "</Relationships>";
    }

    private static String styles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<fonts count=\"3\"><font><sz val=\"11\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"16\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/><family val=\"2\"/></font></fonts>"
                + "<fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill>"
                + "<fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF2457D6\"/></patternFill></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF3F69D8\"/></patternFill></fill></fills>"
                + "<borders count=\"2\"><border/><border><left style=\"thin\"><color rgb=\"FFD9DEE8\"/></left>"
                + "<right style=\"thin\"><color rgb=\"FFD9DEE8\"/></right><top style=\"thin\"><color rgb=\"FFD9DEE8\"/></top>"
                + "<bottom style=\"thin\"><color rgb=\"FFD9DEE8\"/></bottom><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"4\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>"
                + "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\" applyAlignment=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>";
    }

    private static final class SharedStrings {
        private final Map<String, Integer> values = new LinkedHashMap<>();
        private int references;

        int index(String raw) {
            references++;
            String sanitized = sanitizeXmlText(raw);
            Integer existing = values.get(sanitized);
            if (existing != null) return existing;
            int index = values.size();
            values.put(sanitized, index);
            return index;
        }

        String toXml() {
            StringBuilder xml = new StringBuilder(1024 + values.size() * 80);
            xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                    .append("<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"")
                    .append(references).append("\" uniqueCount=\"").append(values.size()).append("\">");
            for (String value : values.keySet()) {
                xml.append("<si><t xml:space=\"preserve\">")
                        .append(escapeXmlText(value)).append("</t></si>");
            }
            return xml.append("</sst>").toString();
        }
    }

    private static String sanitizeXmlText(String value) {
        if (value == null) return "";
        StringBuilder clean = new StringBuilder(value.length());
        value.codePoints().forEach(cp -> {
            if (cp == 0x9 || cp == 0xA || cp == 0xD
                    || (cp >= 0x20 && cp <= 0xD7FF)
                    || (cp >= 0xE000 && cp <= 0xFFFD)
                    || (cp >= 0x10000 && cp <= 0x10FFFF)) {
                clean.appendCodePoint(cp);
            }
        });
        return clean.toString();
    }
}
