package com.andrei.nfcpeople;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class XlsxExporterTest {
    @Test
    public void workbookUsesExcelCompatiblePackageAndSanitizesNames() throws Exception {
        List<AppDatabase.Scan> scans = List.of(
                new AppDatabase.Scan(1, 1, 1, "Ana\u0000 Maria", 1785120000000L, "01"),
                new AppDatabase.Scan(2, 1, 2, "Ion & <Popescu>\u000B", 1785120001000L, "02")
        );
        byte[] workbook = XlsxExporter.create(LocalDate.of(2026, 7, 27), scans);
        XlsxExporter.validate(workbook);

        Map<String, String> parts = new HashMap<>();
        try (ZipInputStream zip = new ZipInputStream(
                new ByteArrayInputStream(workbook), StandardCharsets.UTF_8)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                parts.put(entry.getName(), new String(zip.readAllBytes(), StandardCharsets.UTF_8));
            }
        }

        String sheet = parts.get("xl/worksheets/sheet1.xml");
        String strings = parts.get("xl/sharedStrings.xml");
        assertTrue(sheet.contains("t=\"s\""));
        assertFalse(sheet.contains("<autoFilter"));
        assertTrue(sheet.indexOf("<sheetData>") < sheet.indexOf("<mergeCells"));
        assertFalse(parts.containsKey("docProps/app.xml"));
        assertFalse(parts.containsKey("docProps/core.xml"));
        assertFalse(strings.contains("\u0000"));
        assertFalse(strings.contains("\u000B"));
        assertTrue(strings.contains("Ana Maria"));
        assertTrue(strings.contains("Ion &amp; &lt;Popescu&gt;"));
    }
    @Test
    public void workbookSortsRowsAlphabeticallyAndRenumbersThem() throws Exception {
        List<AppDatabase.Scan> scans = List.of(
                new AppDatabase.Scan(1, 1, 1, "Stefan", 1785120003000L, "01"),
                new AppDatabase.Scan(2, 1, 2, "ana", 1785120002000L, "02"),
                new AppDatabase.Scan(3, 1, 3, "Bogdan", 1785120001000L, "03")
        );
        byte[] workbook = XlsxExporter.create(LocalDate.of(2026, 7, 27), scans);
        XlsxExporter.validate(workbook);

        Map<String, String> parts = new HashMap<>();
        try (ZipInputStream zip = new ZipInputStream(
                new ByteArrayInputStream(workbook), StandardCharsets.UTF_8)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                parts.put(entry.getName(), new String(zip.readAllBytes(), StandardCharsets.UTF_8));
            }
        }

        String strings = parts.get("xl/sharedStrings.xml");
        String sheet = parts.get("xl/worksheets/sheet1.xml");
        assertTrue(strings.indexOf(">ana<") < strings.indexOf(">Bogdan<"));
        assertTrue(strings.indexOf(">Bogdan<") < strings.indexOf(">Stefan<"));
        assertTrue(sheet.contains("<c r=\"A3\" s=\"3\" t=\"n\"><v>1</v></c>"));
        assertTrue(sheet.contains("<c r=\"A4\" s=\"3\" t=\"n\"><v>2</v></c>"));
        assertTrue(sheet.contains("<c r=\"A5\" s=\"3\" t=\"n\"><v>3</v></c>"));
    }

    @Test
    public void workbookMarksScannedAndManualEntriesInSourceColumn() throws Exception {
        List<AppDatabase.Scan> scans = List.of(
                new AppDatabase.Scan(1, 1, 1, "Ana", 1785120000000L, "04A1B2"),
                new AppDatabase.Scan(2, 1, 2, "Bogdan", 1785120001000L, "MANUAL:1785120001000:99")
        );
        byte[] workbook = XlsxExporter.create(LocalDate.of(2026, 7, 27), scans);
        XlsxExporter.validate(workbook);

        Map<String, String> parts = new HashMap<>();
        try (ZipInputStream zip = new ZipInputStream(
                new ByteArrayInputStream(workbook), StandardCharsets.UTF_8)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                parts.put(entry.getName(), new String(zip.readAllBytes(), StandardCharsets.UTF_8));
            }
        }

        String strings = parts.get("xl/sharedStrings.xml");
        String sheet = parts.get("xl/worksheets/sheet1.xml");
        assertTrue(strings.contains(">Source<"));
        assertTrue(strings.contains(">Scan<"));
        assertTrue(strings.contains(">Manual<"));
        assertTrue(sheet.contains("r=\"E2\""));
        assertTrue(sheet.contains("r=\"E3\""));
        assertTrue(sheet.contains("r=\"E4\""));
        assertTrue(sheet.contains("<dimension ref=\"A1:E4\"/>"));
        assertTrue(sheet.contains("<mergeCell ref=\"A1:E1\"/>"));
        assertTrue("Scan".equals(XlsxExporter.sourceLabel(scans.get(0))));
        assertTrue("Manual".equals(XlsxExporter.sourceLabel(scans.get(1))));
    }

}
